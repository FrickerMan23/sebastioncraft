package net.mcreator.sebastiancraft.procedures;

import net.minecraft.world.entity.Entity;

public class ClubLivingEntityIsHitWithToolProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(1);
	}
}
