
package net.mcreator.sebastiancraft.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.sebastiancraft.entity.JJBermudskiEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class JJBermudskiRenderer extends HumanoidMobRenderer<JJBermudskiEntity, HumanoidModel<JJBermudskiEntity>> {
	public JJBermudskiRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	protected void scale(JJBermudskiEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(0.5f, 0.5f, 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(JJBermudskiEntity entity) {
		return new ResourceLocation("sebastiancraft:textures/entities/jjbermudski.png");
	}
}
