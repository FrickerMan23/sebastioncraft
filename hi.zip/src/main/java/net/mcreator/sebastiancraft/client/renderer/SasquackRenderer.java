
package net.mcreator.sebastiancraft.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.sebastiancraft.entity.SasquackEntity;
import net.mcreator.sebastiancraft.client.model.Modelsasquack;

public class SasquackRenderer extends MobRenderer<SasquackEntity, Modelsasquack<SasquackEntity>> {
	public SasquackRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelsasquack(context.bakeLayer(Modelsasquack.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(SasquackEntity entity) {
		return new ResourceLocation("sebastiancraft:textures/entities/sasquackt.png");
	}
}
