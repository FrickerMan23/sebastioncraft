
package net.mcreator.sebastiancraft.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.sebastiancraft.entity.SebEntity;
import net.mcreator.sebastiancraft.client.model.ModelCustomModel;

public class SebRenderer extends MobRenderer<SebEntity, ModelCustomModel<SebEntity>> {
	public SebRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelCustomModel(context.bakeLayer(ModelCustomModel.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(SebEntity entity) {
		return new ResourceLocation("sebastiancraft:textures/entities/rewrew.png");
	}
}
