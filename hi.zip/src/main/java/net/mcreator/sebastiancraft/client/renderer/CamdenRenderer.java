
package net.mcreator.sebastiancraft.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.sebastiancraft.entity.CamdenEntity;
import net.mcreator.sebastiancraft.client.model.Modelcamden;

public class CamdenRenderer extends MobRenderer<CamdenEntity, Modelcamden<CamdenEntity>> {
	public CamdenRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelcamden(context.bakeLayer(Modelcamden.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(CamdenEntity entity) {
		return new ResourceLocation("sebastiancraft:textures/entities/camden.png");
	}
}
