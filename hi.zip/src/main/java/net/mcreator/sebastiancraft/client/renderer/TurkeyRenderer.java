
package net.mcreator.sebastiancraft.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.sebastiancraft.entity.TurkeyEntity;
import net.mcreator.sebastiancraft.client.model.Modelturkey;

public class TurkeyRenderer extends MobRenderer<TurkeyEntity, Modelturkey<TurkeyEntity>> {
	public TurkeyRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelturkey(context.bakeLayer(Modelturkey.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(TurkeyEntity entity) {
		return new ResourceLocation("sebastiancraft:textures/entities/64564564564565645.png");
	}
}
