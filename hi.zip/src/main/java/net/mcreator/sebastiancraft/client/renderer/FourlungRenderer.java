
package net.mcreator.sebastiancraft.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.sebastiancraft.entity.FourlungEntity;
import net.mcreator.sebastiancraft.client.model.Modelfourlung;

public class FourlungRenderer extends MobRenderer<FourlungEntity, Modelfourlung<FourlungEntity>> {
	public FourlungRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelfourlung(context.bakeLayer(Modelfourlung.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(FourlungEntity entity) {
		return new ResourceLocation("sebastiancraft:textures/entities/435345.png");
	}
}
