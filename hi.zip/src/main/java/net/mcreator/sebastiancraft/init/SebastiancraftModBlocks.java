
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.sebastiancraft.block.SlowerBlock;
import net.mcreator.sebastiancraft.block.MainesandBlock;
import net.mcreator.sebastiancraft.block.MainegravelBlock;
import net.mcreator.sebastiancraft.block.MainegrassBlock;
import net.mcreator.sebastiancraft.block.MainePortalBlock;
import net.mcreator.sebastiancraft.block.LeadOreBlock;
import net.mcreator.sebastiancraft.block.LeadBlockBlock;
import net.mcreator.sebastiancraft.block.FirstairBlock;
import net.mcreator.sebastiancraft.block.FirslabBlock;
import net.mcreator.sebastiancraft.block.FirplankBlock;
import net.mcreator.sebastiancraft.block.FirlogBlock;
import net.mcreator.sebastiancraft.block.FirfenceBlock;
import net.mcreator.sebastiancraft.SebastiancraftMod;

public class SebastiancraftModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, SebastiancraftMod.MODID);
	public static final RegistryObject<Block> SLOWER = REGISTRY.register("slower", () -> new SlowerBlock());
	public static final RegistryObject<Block> MAINESAND = REGISTRY.register("mainesand", () -> new MainesandBlock());
	public static final RegistryObject<Block> MAINEGRASS = REGISTRY.register("mainegrass", () -> new MainegrassBlock());
	public static final RegistryObject<Block> MAINEGRAVEL = REGISTRY.register("mainegravel", () -> new MainegravelBlock());
	public static final RegistryObject<Block> FIRLOG = REGISTRY.register("firlog", () -> new FirlogBlock());
	public static final RegistryObject<Block> FIRPLANK = REGISTRY.register("firplank", () -> new FirplankBlock());
	public static final RegistryObject<Block> MAINE_PORTAL = REGISTRY.register("maine_portal", () -> new MainePortalBlock());
	public static final RegistryObject<Block> FIRSLAB = REGISTRY.register("firslab", () -> new FirslabBlock());
	public static final RegistryObject<Block> FIRSTAIR = REGISTRY.register("firstair", () -> new FirstairBlock());
	public static final RegistryObject<Block> FIRFENCE = REGISTRY.register("firfence", () -> new FirfenceBlock());
	public static final RegistryObject<Block> LEAD_ORE = REGISTRY.register("lead_ore", () -> new LeadOreBlock());
	public static final RegistryObject<Block> LEAD_BLOCK = REGISTRY.register("lead_block", () -> new LeadBlockBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			MainegrassBlock.blockColorLoad(event);
		}
	}
}
