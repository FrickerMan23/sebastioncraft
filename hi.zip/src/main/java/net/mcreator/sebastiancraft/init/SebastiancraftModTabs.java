
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.sebastiancraft.SebastiancraftMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SebastiancraftModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SebastiancraftMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(SebastiancraftModBlocks.LEAD_ORE.get().asItem());
			tabData.accept(SebastiancraftModBlocks.LEAD_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(SebastiancraftModItems.LEAD_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(SebastiancraftModItems.SEB_SPAWN_EGG.get());
			tabData.accept(SebastiancraftModItems.SASQUACK_SPAWN_EGG.get());
			tabData.accept(SebastiancraftModItems.CAMDEN_SPAWN_EGG.get());
			tabData.accept(SebastiancraftModItems.FOURLUNG_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(SebastiancraftModItems.LEAD_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(SebastiancraftModBlocks.SLOWER.get().asItem());
			tabData.accept(SebastiancraftModBlocks.MAINEGRASS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(SebastiancraftModItems.LOBSTERTOOL.get());
			tabData.accept(SebastiancraftModItems.MAINEPICKAXE.get());
			tabData.accept(SebastiancraftModItems.MAINESHOVEL.get());
			tabData.accept(SebastiancraftModItems.MAINEAXE.get());
			tabData.accept(SebastiancraftModItems.CLUB.get());
			tabData.accept(SebastiancraftModItems.MAINEHOE.get());
			tabData.accept(SebastiancraftModItems.MAINE.get());
			tabData.accept(SebastiancraftModItems.LEAD_PICKAXE.get());
			tabData.accept(SebastiancraftModItems.LEAD_AXE.get());
			tabData.accept(SebastiancraftModItems.LEAD_SHOVEL.get());
			tabData.accept(SebastiancraftModItems.LEAD_HOE.get());
		}
	}
}
