
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.sebastiancraft.client.model.Modelsasquack;
import net.mcreator.sebastiancraft.client.model.Modelfourlung;
import net.mcreator.sebastiancraft.client.model.Modelcamden;
import net.mcreator.sebastiancraft.client.model.ModelCustomModel;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class SebastiancraftModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelCustomModel.LAYER_LOCATION, ModelCustomModel::createBodyLayer);
		event.registerLayerDefinition(Modelfourlung.LAYER_LOCATION, Modelfourlung::createBodyLayer);
		event.registerLayerDefinition(Modelsasquack.LAYER_LOCATION, Modelsasquack::createBodyLayer);
		event.registerLayerDefinition(Modelcamden.LAYER_LOCATION, Modelcamden::createBodyLayer);
	}
}
