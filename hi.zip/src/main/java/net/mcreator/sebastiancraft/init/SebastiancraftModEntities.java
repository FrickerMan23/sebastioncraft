
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.sebastiancraft.entity.SebEntity;
import net.mcreator.sebastiancraft.entity.SasquackEntity;
import net.mcreator.sebastiancraft.entity.FourlungEntity;
import net.mcreator.sebastiancraft.entity.CamdenEntity;
import net.mcreator.sebastiancraft.SebastiancraftMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SebastiancraftModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SebastiancraftMod.MODID);
	public static final RegistryObject<EntityType<SebEntity>> SEB = register("seb",
			EntityType.Builder.<SebEntity>of(SebEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(256).setUpdateInterval(3).setCustomClientFactory(SebEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SasquackEntity>> SASQUACK = register("sasquack",
			EntityType.Builder.<SasquackEntity>of(SasquackEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SasquackEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<CamdenEntity>> CAMDEN = register("camden",
			EntityType.Builder.<CamdenEntity>of(CamdenEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(128).setUpdateInterval(3).setCustomClientFactory(CamdenEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FourlungEntity>> FOURLUNG = register("fourlung",
			EntityType.Builder.<FourlungEntity>of(FourlungEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FourlungEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SebEntity.init();
			SasquackEntity.init();
			CamdenEntity.init();
			FourlungEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SEB.get(), SebEntity.createAttributes().build());
		event.put(SASQUACK.get(), SasquackEntity.createAttributes().build());
		event.put(CAMDEN.get(), CamdenEntity.createAttributes().build());
		event.put(FOURLUNG.get(), FourlungEntity.createAttributes().build());
	}
}
