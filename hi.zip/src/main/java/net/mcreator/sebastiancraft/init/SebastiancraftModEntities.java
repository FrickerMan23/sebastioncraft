
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.sebastiancraft.entity.WalkerEntity;
import net.mcreator.sebastiancraft.entity.TurkeyEntity;
import net.mcreator.sebastiancraft.entity.SebEntity;
import net.mcreator.sebastiancraft.entity.SasquackEntity;
import net.mcreator.sebastiancraft.entity.MusketballEntity;
import net.mcreator.sebastiancraft.entity.MondasianFourLungEntity;
import net.mcreator.sebastiancraft.entity.JJBermudskiEntity;
import net.mcreator.sebastiancraft.entity.GlockbulletEntity;
import net.mcreator.sebastiancraft.entity.FourlungEntity;
import net.mcreator.sebastiancraft.entity.FirewalkerballEntity;
import net.mcreator.sebastiancraft.entity.FirewalkerEntity;
import net.mcreator.sebastiancraft.entity.CamdenEntity;
import net.mcreator.sebastiancraft.SebastiancraftMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SebastiancraftModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SebastiancraftMod.MODID);
	public static final RegistryObject<EntityType<SebEntity>> SEB = register("seb",
			EntityType.Builder.<SebEntity>of(SebEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(256).setUpdateInterval(3).setCustomClientFactory(SebEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SasquackEntity>> SASQUACK = register("sasquack",
			EntityType.Builder.<SasquackEntity>of(SasquackEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SasquackEntity::new)

					.sized(1.4f, 2.7f));
	public static final RegistryObject<EntityType<CamdenEntity>> CAMDEN = register("camden",
			EntityType.Builder.<CamdenEntity>of(CamdenEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(128).setUpdateInterval(3).setCustomClientFactory(CamdenEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FourlungEntity>> FOURLUNG = register("fourlung",
			EntityType.Builder.<FourlungEntity>of(FourlungEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FourlungEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<WalkerEntity>> WALKER = register("walker",
			EntityType.Builder.<WalkerEntity>of(WalkerEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(256).setUpdateInterval(3).setCustomClientFactory(WalkerEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FirewalkerEntity>> FIREWALKER = register("firewalker", EntityType.Builder.<FirewalkerEntity>of(FirewalkerEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(512)
			.setUpdateInterval(3).setCustomClientFactory(FirewalkerEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FirewalkerballEntity>> FIREWALKERBALL = register("firewalkerball",
			EntityType.Builder.<FirewalkerballEntity>of(FirewalkerballEntity::new, MobCategory.MISC).setCustomClientFactory(FirewalkerballEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TurkeyEntity>> TURKEY = register("turkey",
			EntityType.Builder.<TurkeyEntity>of(TurkeyEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TurkeyEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<MusketballEntity>> MUSKETBALL = register("musketball",
			EntityType.Builder.<MusketballEntity>of(MusketballEntity::new, MobCategory.MISC).setCustomClientFactory(MusketballEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<MondasianFourLungEntity>> MONDASIAN_FOUR_LUNG = register("mondasian_four_lung",
			EntityType.Builder.<MondasianFourLungEntity>of(MondasianFourLungEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(256).setUpdateInterval(3).setCustomClientFactory(MondasianFourLungEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<JJBermudskiEntity>> JJ_BERMUDSKI = register("jj_bermudski",
			EntityType.Builder.<JJBermudskiEntity>of(JJBermudskiEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(JJBermudskiEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<GlockbulletEntity>> GLOCKBULLET = register("glockbullet",
			EntityType.Builder.<GlockbulletEntity>of(GlockbulletEntity::new, MobCategory.MISC).setCustomClientFactory(GlockbulletEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SebEntity.init();
			SasquackEntity.init();
			CamdenEntity.init();
			FourlungEntity.init();
			WalkerEntity.init();
			FirewalkerEntity.init();
			TurkeyEntity.init();
			MondasianFourLungEntity.init();
			JJBermudskiEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SEB.get(), SebEntity.createAttributes().build());
		event.put(SASQUACK.get(), SasquackEntity.createAttributes().build());
		event.put(CAMDEN.get(), CamdenEntity.createAttributes().build());
		event.put(FOURLUNG.get(), FourlungEntity.createAttributes().build());
		event.put(WALKER.get(), WalkerEntity.createAttributes().build());
		event.put(FIREWALKER.get(), FirewalkerEntity.createAttributes().build());
		event.put(TURKEY.get(), TurkeyEntity.createAttributes().build());
		event.put(MONDASIAN_FOUR_LUNG.get(), MondasianFourLungEntity.createAttributes().build());
		event.put(JJ_BERMUDSKI.get(), JJBermudskiEntity.createAttributes().build());
	}
}
