
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.sebastiancraft.client.renderer.WalkerRenderer;
import net.mcreator.sebastiancraft.client.renderer.TurkeyRenderer;
import net.mcreator.sebastiancraft.client.renderer.SebRenderer;
import net.mcreator.sebastiancraft.client.renderer.SasquackRenderer;
import net.mcreator.sebastiancraft.client.renderer.MondasianFourLungRenderer;
import net.mcreator.sebastiancraft.client.renderer.JJBermudskiRenderer;
import net.mcreator.sebastiancraft.client.renderer.FourlungRenderer;
import net.mcreator.sebastiancraft.client.renderer.FirewalkerRenderer;
import net.mcreator.sebastiancraft.client.renderer.CamdenRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SebastiancraftModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(SebastiancraftModEntities.SEB.get(), SebRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.SASQUACK.get(), SasquackRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.CAMDEN.get(), CamdenRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.FOURLUNG.get(), FourlungRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.WALKER.get(), WalkerRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.FIREWALKER.get(), FirewalkerRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.FIREWALKERBALL.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.TURKEY.get(), TurkeyRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.MUSKETBALL.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.MONDASIAN_FOUR_LUNG.get(), MondasianFourLungRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.JJ_BERMUDSKI.get(), JJBermudskiRenderer::new);
		event.registerEntityRenderer(SebastiancraftModEntities.GLOCKBULLET.get(), ThrownItemRenderer::new);
	}
}
