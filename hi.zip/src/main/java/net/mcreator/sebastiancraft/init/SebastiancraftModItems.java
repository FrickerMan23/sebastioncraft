
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.sebastiancraft.item.MusketballunobtainItem;
import net.mcreator.sebastiancraft.item.MaineshovelItem;
import net.mcreator.sebastiancraft.item.MainepickaxeItem;
import net.mcreator.sebastiancraft.item.MainehoeItem;
import net.mcreator.sebastiancraft.item.MaineaxeItem;
import net.mcreator.sebastiancraft.item.MaineItem;
import net.mcreator.sebastiancraft.item.LobstertoolItem;
import net.mcreator.sebastiancraft.item.LeadSwordItem;
import net.mcreator.sebastiancraft.item.LeadShovelItem;
import net.mcreator.sebastiancraft.item.LeadPickaxeItem;
import net.mcreator.sebastiancraft.item.LeadIngotItem;
import net.mcreator.sebastiancraft.item.LeadHoeItem;
import net.mcreator.sebastiancraft.item.LeadAxeItem;
import net.mcreator.sebastiancraft.item.JJBermudskiGlockItem;
import net.mcreator.sebastiancraft.item.Flintlock1Item;
import net.mcreator.sebastiancraft.item.ClubItem;
import net.mcreator.sebastiancraft.SebastiancraftMod;

public class SebastiancraftModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, SebastiancraftMod.MODID);
	public static final RegistryObject<Item> SLOWER = doubleBlock(SebastiancraftModBlocks.SLOWER);
	public static final RegistryObject<Item> LOBSTERTOOL = REGISTRY.register("lobstertool", () -> new LobstertoolItem());
	public static final RegistryObject<Item> MAINESAND = block(SebastiancraftModBlocks.MAINESAND);
	public static final RegistryObject<Item> MAINEGRASS = block(SebastiancraftModBlocks.MAINEGRASS);
	public static final RegistryObject<Item> MAINEGRAVEL = block(SebastiancraftModBlocks.MAINEGRAVEL);
	public static final RegistryObject<Item> FIRLOG = block(SebastiancraftModBlocks.FIRLOG);
	public static final RegistryObject<Item> FIRPLANK = block(SebastiancraftModBlocks.FIRPLANK);
	public static final RegistryObject<Item> MAINEPICKAXE = REGISTRY.register("mainepickaxe", () -> new MainepickaxeItem());
	public static final RegistryObject<Item> MAINESHOVEL = REGISTRY.register("maineshovel", () -> new MaineshovelItem());
	public static final RegistryObject<Item> MAINEAXE = REGISTRY.register("maineaxe", () -> new MaineaxeItem());
	public static final RegistryObject<Item> CLUB = REGISTRY.register("club", () -> new ClubItem());
	public static final RegistryObject<Item> MAINEHOE = REGISTRY.register("mainehoe", () -> new MainehoeItem());
	public static final RegistryObject<Item> SEB_SPAWN_EGG = REGISTRY.register("seb_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.SEB, -52429, -1, new Item.Properties()));
	public static final RegistryObject<Item> SASQUACK_SPAWN_EGG = REGISTRY.register("sasquack_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.SASQUACK, -3381760, -10092544, new Item.Properties()));
	public static final RegistryObject<Item> MAINE = REGISTRY.register("maine", () -> new MaineItem());
	public static final RegistryObject<Item> CAMDEN_SPAWN_EGG = REGISTRY.register("camden_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.CAMDEN, -16763956, -13395712, new Item.Properties()));
	public static final RegistryObject<Item> FIRSLAB = block(SebastiancraftModBlocks.FIRSLAB);
	public static final RegistryObject<Item> FIRSTAIR = block(SebastiancraftModBlocks.FIRSTAIR);
	public static final RegistryObject<Item> FIRFENCE = block(SebastiancraftModBlocks.FIRFENCE);
	public static final RegistryObject<Item> LEAD_INGOT = REGISTRY.register("lead_ingot", () -> new LeadIngotItem());
	public static final RegistryObject<Item> LEAD_ORE = block(SebastiancraftModBlocks.LEAD_ORE);
	public static final RegistryObject<Item> LEAD_BLOCK = block(SebastiancraftModBlocks.LEAD_BLOCK);
	public static final RegistryObject<Item> LEAD_PICKAXE = REGISTRY.register("lead_pickaxe", () -> new LeadPickaxeItem());
	public static final RegistryObject<Item> LEAD_AXE = REGISTRY.register("lead_axe", () -> new LeadAxeItem());
	public static final RegistryObject<Item> LEAD_SWORD = REGISTRY.register("lead_sword", () -> new LeadSwordItem());
	public static final RegistryObject<Item> LEAD_SHOVEL = REGISTRY.register("lead_shovel", () -> new LeadShovelItem());
	public static final RegistryObject<Item> LEAD_HOE = REGISTRY.register("lead_hoe", () -> new LeadHoeItem());
	public static final RegistryObject<Item> FOURLUNG_SPAWN_EGG = REGISTRY.register("fourlung_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.FOURLUNG, -256, -16777012, new Item.Properties()));
	public static final RegistryObject<Item> WALKER_SPAWN_EGG = REGISTRY.register("walker_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.WALKER, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> FIREWALKER_SPAWN_EGG = REGISTRY.register("firewalker_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.FIREWALKER, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> TURKEY_SPAWN_EGG = REGISTRY.register("turkey_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.TURKEY, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> MUSKETBALLUNOBTAIN = REGISTRY.register("musketballunobtain", () -> new MusketballunobtainItem());
	public static final RegistryObject<Item> FLINTLOCK = REGISTRY.register("flintlock", () -> new Flintlock1Item());
	public static final RegistryObject<Item> MONDASIAN_FOUR_LUNG_SPAWN_EGG = REGISTRY.register("mondasian_four_lung_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.MONDASIAN_FOUR_LUNG, -205, -6750055, new Item.Properties()));
	public static final RegistryObject<Item> JJ_BERMUDSKI_SPAWN_EGG = REGISTRY.register("jj_bermudski_spawn_egg", () -> new ForgeSpawnEggItem(SebastiancraftModEntities.JJ_BERMUDSKI, -13210, -6750208, new Item.Properties()));
	public static final RegistryObject<Item> JJ_BERMUDSKI_GLOCK = REGISTRY.register("jj_bermudski_glock", () -> new JJBermudskiGlockItem());
	public static final RegistryObject<Item> AMATOSIGNSECTION = block(SebastiancraftModBlocks.AMATOSIGNSECTION);
	public static final RegistryObject<Item> AMATOSIGNSECTION_2 = block(SebastiancraftModBlocks.AMATOSIGNSECTION_2);
	public static final RegistryObject<Item> AMATOSIGNSECTION_3 = block(SebastiancraftModBlocks.AMATOSIGNSECTION_3);
	public static final RegistryObject<Item> AMATOSIGNSECTION_4 = block(SebastiancraftModBlocks.AMATOSIGNSECTION_4);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}
}
