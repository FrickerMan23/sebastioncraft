
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.sebastiancraft.SebastiancraftMod;

public class SebastiancraftModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SebastiancraftMod.MODID);
	public static final RegistryObject<SoundEvent> HI = REGISTRY.register("hi", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "hi")));
	public static final RegistryObject<SoundEvent> SAQHURT = REGISTRY.register("saqhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "saqhurt")));
	public static final RegistryObject<SoundEvent> LIVE = REGISTRY.register("live", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "live")));
	public static final RegistryObject<SoundEvent> SAQDEATH = REGISTRY.register("saqdeath", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "saqdeath")));
	public static final RegistryObject<SoundEvent> SEBLIVE = REGISTRY.register("seblive", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "seblive")));
	public static final RegistryObject<SoundEvent> SEBSTEPS = REGISTRY.register("sebsteps", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "sebsteps")));
	public static final RegistryObject<SoundEvent> SEBHURT = REGISTRY.register("sebhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "sebhurt")));
	public static final RegistryObject<SoundEvent> SEBDIES = REGISTRY.register("sebdies", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "sebdies")));
	public static final RegistryObject<SoundEvent> CAMDENDIES = REGISTRY.register("camdendies", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "camdendies")));
	public static final RegistryObject<SoundEvent> CAMDENLIVES = REGISTRY.register("camdenlives", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "camdenlives")));
	public static final RegistryObject<SoundEvent> CAMDENSTEP = REGISTRY.register("camdenstep", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "camdenstep")));
	public static final RegistryObject<SoundEvent> CAMDENHURT = REGISTRY.register("camdenhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "camdenhurt")));
}
