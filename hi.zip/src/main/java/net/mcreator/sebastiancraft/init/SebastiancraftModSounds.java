
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sebastiancraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.sebastiancraft.SebastiancraftMod;

public class SebastiancraftModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SebastiancraftMod.MODID);
	public static final RegistryObject<SoundEvent> HI = REGISTRY.register("hi", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "hi")));
	public static final RegistryObject<SoundEvent> SAQHURT = REGISTRY.register("saqhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "saqhurt")));
	public static final RegistryObject<SoundEvent> LIVE = REGISTRY.register("live", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "live")));
	public static final RegistryObject<SoundEvent> SAQDEATH = REGISTRY.register("saqdeath", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "saqdeath")));
	public static final RegistryObject<SoundEvent> SEBLIVE = REGISTRY.register("seblive", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "seblive")));
	public static final RegistryObject<SoundEvent> SEBSTEPS = REGISTRY.register("sebsteps", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "sebsteps")));
	public static final RegistryObject<SoundEvent> SEBHURT = REGISTRY.register("sebhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "sebhurt")));
	public static final RegistryObject<SoundEvent> SEBDIES = REGISTRY.register("sebdies", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "sebdies")));
	public static final RegistryObject<SoundEvent> CAMDENDIES = REGISTRY.register("camdendies", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "camdendies")));
	public static final RegistryObject<SoundEvent> CAMDENLIVES = REGISTRY.register("camdenlives", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "camdenlives")));
	public static final RegistryObject<SoundEvent> CAMDENSTEP = REGISTRY.register("camdenstep", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "camdenstep")));
	public static final RegistryObject<SoundEvent> CAMDENHURT = REGISTRY.register("camdenhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "camdenhurt")));
	public static final RegistryObject<SoundEvent> FIREWALKERSHOOT = REGISTRY.register("firewalkershoot", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "firewalkershoot")));
	public static final RegistryObject<SoundEvent> FLINTLOCKFIRE = REGISTRY.register("flintlockfire", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "flintlockfire")));
	public static final RegistryObject<SoundEvent> WALKERSTEP = REGISTRY.register("walkerstep", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "walkerstep")));
	public static final RegistryObject<SoundEvent> WALKERIDLE = REGISTRY.register("walkeridle", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "walkeridle")));
	public static final RegistryObject<SoundEvent> WALKERHURT = REGISTRY.register("walkerhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "walkerhurt")));
	public static final RegistryObject<SoundEvent> WALKERDEATH = REGISTRY.register("walkerdeath", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "walkerdeath")));
	public static final RegistryObject<SoundEvent> FIREWALKERHURT = REGISTRY.register("firewalkerhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "firewalkerhurt")));
	public static final RegistryObject<SoundEvent> FIREWALKERDEATH = REGISTRY.register("firewalkerdeath", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "firewalkerdeath")));
	public static final RegistryObject<SoundEvent> FIREWALKERIDLE = REGISTRY.register("firewalkeridle", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "firewalkeridle")));
	public static final RegistryObject<SoundEvent> FOURLUNGIDLE = REGISTRY.register("fourlungidle", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "fourlungidle")));
	public static final RegistryObject<SoundEvent> FOURLUNGHURT = REGISTRY.register("fourlunghurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "fourlunghurt")));
	public static final RegistryObject<SoundEvent> FOURLUNGDEATH = REGISTRY.register("fourlungdeath", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "fourlungdeath")));
	public static final RegistryObject<SoundEvent> TURKEYIDLE = REGISTRY.register("turkeyidle", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "turkeyidle")));
	public static final RegistryObject<SoundEvent> TURKEYHURT = REGISTRY.register("turkeyhurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "turkeyhurt")));
	public static final RegistryObject<SoundEvent> TURKEYDEATH = REGISTRY.register("turkeydeath", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sebastiancraft", "turkeydeath")));
}
