
package net.mcreator.sebastiancraft.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class MusketballunobtainItem extends Item {
	public MusketballunobtainItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
