
package net.mcreator.sebastiancraft.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.sebastiancraft.procedures.LeadSwordLivingEntityIsHitWithToolProcedure;
import net.mcreator.sebastiancraft.init.SebastiancraftModItems;

public class LeadSwordItem extends SwordItem {
	public LeadSwordItem() {
		super(new Tier() {
			public int getUses() {
				return 470;
			}

			public float getSpeed() {
				return 8f;
			}

			public float getAttackDamageBonus() {
				return 3f;
			}

			public int getLevel() {
				return 3;
			}

			public int getEnchantmentValue() {
				return 21;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(SebastiancraftModItems.LEAD_INGOT.get()));
			}
		}, 3, 1f, new Item.Properties());
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		LeadSwordLivingEntityIsHitWithToolProcedure.execute(entity);
		return retval;
	}
}
